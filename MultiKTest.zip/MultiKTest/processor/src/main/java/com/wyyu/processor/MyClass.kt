package com.wyyu.processor

class MyClass {
}