package wyyu.multi.normal;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import wyyu.multi.R;

/**
 * Created by wyyu on 2020-05-07.
 **/

public class ActivityListNormal extends AppCompatActivity {

    public static void open(Context context) {
        context.startActivity(new Intent(context, ActivityListNormal.class));
    }

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_normal);
    }
}
